from django.contrib import admin
from backend.meeting.models import MeetingRoom

# Register your models here.
admin.site.register(MeetingRoom)